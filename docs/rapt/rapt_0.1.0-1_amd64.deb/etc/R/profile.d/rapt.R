## Enable rapt if installed
if (requireNamespace("rapt", quietly = TRUE)) rapt::enable()
